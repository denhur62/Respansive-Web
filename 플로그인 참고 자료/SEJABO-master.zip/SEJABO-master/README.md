# SeJaBo
Sejong University Project / Team IML 

## What is SeJaBo?
Information sharing SNS service for Sejong University students

## You need this
1. Python 3.7
2. MySQL 5.7.25 or 8.0.5
3. Not Supported Internet Explorer

## How to use

```c
$ cd SeJaBo
$ pip install -r requirement.txt
$ cd src
$ python app.py
```
